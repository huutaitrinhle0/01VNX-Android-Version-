plugins {
    id("com.android.application")
}

android {
    namespace = "com.ovx.scriptstudio"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.ovx.scriptstudio"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            val ksPath = System.getenv("OVX_KEYSTORE_FILE")
            if (!ksPath.isNullOrBlank()) {
                signingConfig = signingConfigs.create("releaseEnv").apply {
                    storeFile = file(ksPath)
                    storePassword = System.getenv("OVX_KEYSTORE_PASSWORD")
                    keyAlias = System.getenv("OVX_KEY_ALIAS")
                    keyPassword = System.getenv("OVX_KEY_PASSWORD")
                }
            }
        }
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

java {
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(17))
    }
}
