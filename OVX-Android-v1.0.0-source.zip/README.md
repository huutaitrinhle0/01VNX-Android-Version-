# OVX Script Studio — Android 1.0.0

Official Android shell for the original OVX Script Studio prototype.

## What it is
- Android application: `com.ovx.scriptstudio`
- Local JavaScript runner in a WebView + Worker
- LocalStorage script library
- Android share/export bridge
- Optional AI Assistant endpoint
- No Delta X branding/code/assets
- No third-party injection, anti-cheat bypass, or code execution inside other apps

Android WebView is the supported mechanism for embedding web content inside an Android client:
https://developer.android.com/develop/ui/views/layout/webapps/webview

## AI architecture
The Android app does **not** embed an OpenAI API key.

The optional AI Assistant calls:
`{YOUR_BACKEND_URL}/api/chat`

The backend keeps `OPENAI_API_KEY` server-side and calls OpenAI's Responses API.

OpenAI explicitly says never to deploy API keys in browsers or mobile apps:
https://help.openai.com/en/articles/5112595-best-practices-for-api-key-safety

## GitHub release
For a clean public project, create a separate repository named `OVX-Android`.

Release flow:
1. Push this project to `main`.
2. Generate a private Android signing keystore.
3. Add GitHub Actions secrets:
   - `OVX_KEYSTORE_B64`
   - `OVX_KEYSTORE_PASSWORD`
   - `OVX_KEY_ALIAS`
   - `OVX_KEY_PASSWORD`
4. Create a tag such as `v1.0.0`.
5. GitHub Actions builds a signed APK and AAB and creates a GitHub Release.

GitHub Releases are designed for distributing deployable software and binary files:
https://docs.github.com/en/repositories/releasing-projects-on-github/about-releases

## Security
Never commit:
- the Android keystore
- OpenAI API keys
- other private credentials
