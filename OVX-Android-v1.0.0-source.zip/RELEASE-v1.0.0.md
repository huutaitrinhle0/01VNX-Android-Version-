# OVX Script Studio Android v1.0.0

## Release scope
- Android 8.0+ (API 26+)
- Target API 36 for current Google Play submission requirements
- Signed APK for direct distribution
- Signed AAB for Google Play
- Local JavaScript runner
- Optional server-side OpenAI Responses API integration

## Not included
- Code injection into third-party apps
- Anti-cheat bypass
- Delta X code, branding, logo, or assets

## Store prerequisites
Google Play requires new apps to publish using Android App Bundles and, as of August 31, 2026, new apps/updates must target Android 16 (API 36) or higher.

The release pipeline therefore targets API 36 and produces both AAB and APK.
